# SistemaParqueadero
Un sistema de parqueadero - propuesta de proyecto final para la materia Desarrollo de Software.

![Aquí la descripción de la imagen por si no carga](https://raw.githubusercontent.com/jeom0/SistemaParqueadero/master/src/imagenes/captura1ProyectoParqueadero.png)
